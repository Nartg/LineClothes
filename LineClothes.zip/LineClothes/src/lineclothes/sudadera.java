/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lineclothes;

/**
 *
 * @author Gerry
 */
public class sudadera extends producto{
    private String tipo;

    public sudadera(String tipo, Integer codigo, String marca, String talla, String color, double costo) {
        super(codigo, marca, talla, color, costo);
        this.tipo = tipo;
    }

    public sudadera() {
    }
    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return tipo;
    }

    

    
    
}
