/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lineclothes;

/**
 *
 * @author Gerry
 */
public class producto {
    private Integer codigo;
    private String marca;
    private String talla;
    private String color;
    private double costo;

    public producto(Integer codigo, String marca, String talla, String color, double costo) {
        this.codigo = codigo;
        this.marca = marca;
        this.talla = talla;
        this.color = color;
        this.costo = costo;
    }

    public producto() {
    }
    
    

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    @Override
    public String toString() {
        return "producto{" + "codigo=" + codigo + ", marca=" + marca + ", talla=" + talla + ", color=" + color + ", costo=" + costo + '}';
    }
    
    
    
    
}
