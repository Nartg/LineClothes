/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lineclothes;

/**
 *
 * @author Gerry
 */
public class pantalon extends producto {
    private String modelo;

    public pantalon(String tipo, Integer codigo,
            String marca, String talla, String color, double costo) {
        super(codigo, marca, talla, color, costo);
        this.modelo = tipo;
    }

    public pantalon() {
    }

    
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    @Override
    public String toString() {
        return  modelo;
    }
}
