/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lineclothes;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Gerry
 */
public class archivo {
    private final Date fecha=new Date();
    private final String ruta = "C:/Users/Gerry/Documents/NetBeansProjects/LineClothes/pedido.txt";
    private final String cabecera = "\n\nPor medio de la presente deseo hacer un pedido,\n"
                                    + "cuyas caracteristicas se presentan a continuacion:";
    private final String pie = "\n\n\nLe solicitamos de la manera más atenta que toda la mercancía sea \n"
                                + "debidamente empaqueta para que no sufra ningún golpe o desperfecto\n "
                                + "durante su traslado"
                                +"\n\nATTE. \n Almacenista";
    
    public boolean existeArchivo() {
        try {
            File archivo = new File(this.ruta);
            return archivo.exists();
        } catch(Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public void creaArchivo() {
        try  {
            if (!existeArchivo()) {
                File archivo = new File(this.ruta);
                archivo.createNewFile();
                System.out.println("Archivo creado");
                FileWriter fw = new FileWriter(archivo, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("\t\t\t\t" + fecha);
                bw.write(cabecera);
                bw.close();
                fw.close();
            }
        } catch(Exception e) {
            e.printStackTrace();
            System.out.println("Error al crear el archivo");
        }
    }
    public void escribirPantalones(int cantidad){
        if (existeArchivo()) {
            try {
                File archivo = new File(this.ruta);
                FileWriter fw = new FileWriter(archivo, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("\nPantalones: " + cantidad);
                bw.close();
                fw.close();
            } catch (IOException e) {
            }
        } else {
            creaArchivo();
            escribirPantalones(cantidad);
        }
    }
    public void escribirPlayeras (int cantidad){
        if (existeArchivo()) {
            try {
                File archivo = new File(this.ruta);
                FileWriter fw = new FileWriter(archivo, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("\nPlayeras: " + cantidad);
                bw.close();
                fw.close();
            } catch (IOException e) {
            }
        } else {
            creaArchivo();
            escribirPlayeras(cantidad);
        }
    }
    public void escribirCamisas(int cantidad) {
        if (existeArchivo()) {
            try {
                File archivo = new File(this.ruta);
                FileWriter fw = new FileWriter(archivo, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("\nCamisas: " + cantidad);
                bw.close();
                fw.close();
            } catch (Exception e) {
            }
        } else {
            creaArchivo();
            escribirCamisas(cantidad);
        }
    }
    public void escribirChamarras(int cantidad) {
        if (existeArchivo()) {
            try {
                File archivo = new File(this.ruta);
                FileWriter fw = new FileWriter(archivo, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("\nChamarras: " + cantidad);
                bw.close();
                fw.close();
            } catch (Exception e) {
            }
        } else {
            creaArchivo();
            escribirChamarras(cantidad);
        }
    }
    public void escribirSudaderas(int cantidad) {
        if (existeArchivo()) {
            try {
                File archivo = new File(this.ruta);
                FileWriter fw = new FileWriter(archivo, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("\nSudaderas: " + cantidad);
                bw.close();
                fw.close();
            } catch (Exception e) {
            }
        } else {
            creaArchivo();
            escribirSudaderas(cantidad);
        }
    }
    public void escribePie() {
        if (existeArchivo()) {
            try {
                File archivo = new File(this.ruta);
                FileWriter fw = new FileWriter(archivo, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(pie);
                bw.close();
                fw.close();
            } catch (Exception e) {
            }
        }
    }
}
