/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lineclothes;

import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Gerry
 */


public class LineClothes extends javax.swing.JFrame {

    inventario lista = new inventario();
    inventario lista2 = new inventario();
    pantalon nuevoPantalon = new pantalon();
    camisa nuevaCamisa = new camisa();
    sudadera nuevaSudadera = new sudadera();
    chamarra nuevaChamarra = new chamarra();
    playera nuevaPlayera = new playera();
    
    
    String busqueda;
    double limiteInf;
    double limiteSup;
    Integer numero_busqueda;
    
    /**
     * Creates new form LineClothes
     */
    public LineClothes() {

        initComponents();
        
        ImageIcon imgIcon = new ImageIcon(getClass().getResource("/imagenes/lineClothes.jpg"));
        Image imgEscalada = imgIcon.getImage().getScaledInstance(jLimagen.getWidth(), jLimagen.getHeight(), Image.SCALE_SMOOTH);
        Icon iconoEscalado = new ImageIcon(imgEscalada);
        jLimagen.setIcon(iconoEscalado);
        this.getContentPane().setBackground(Color.white);
        this.repaint();

        pantalon p1 = new pantalon("estrechos",1,"patito","mediana","negro",345.67);
        pantalon p2 = new pantalon("estrechos",1,"patito","mediana","blaco",5345.67);
        pantalon p3 = new pantalon("estrechos",1,"patito","mediana","cafe",3675.67);
        lista.agregarProducto(p1);
        lista.agregarProducto(p2);
        lista.agregarProducto(p3);
        playera p4 = new playera("paloma", 7,"cyrus","XL","Blanco",566.89);
        playera p5 = new playera("recto", 7,"cyrus","ML","Negro",56766.89);
        playera p6 = new playera("paloma", 7,"cyrus","XXL","Blanco",56600.89);
        playera p7 = new playera("paloma", 7,"cyrus","XL","Blanco",566.1189);
        lista.agregarProducto(p4);
        lista.agregarProducto(p5);
        lista.agregarProducto(p6);
        lista.agregarProducto(p7);
        mostrar();
        /*
        for(int j=0;j<lista.tamaño();j++){
            System.out.println(""+lista.get(j).toString());
        }
        */
    }
    
    public void mostrar(){
        int i;
        String [][] matriz=new String[lista.tamaño()][7];
        for( i=0;i<lista.tamaño();i++){
            matriz[i][0]=lista.get(i).getClass().getSimpleName();
            matriz[i][1]=String.valueOf(lista.get(i).getCodigo());
            matriz[i][2]=lista.get(i).getMarca();
            matriz[i][3]=lista.get(i).getTalla();
            matriz[i][4]=lista.get(i).getColor();
            matriz[i][5]=String.valueOf(lista.get(i).getCosto());
            if(lista.get(i).getClass().getSimpleName().equals("pantalon")){
               matriz[i][6]=lista.get(i).toString();
            }else{
                if(lista.get(i).getClass().getSimpleName().equals("playera")){
                    matriz[i][6]=lista.get(i).toString();
                }
                else{
                    if(lista.get(i).getClass().getSimpleName().equals("chamarra")){
                        matriz[i][6]=lista.get(i).toString();
                    }
                    else{
                        if(lista.get(i).getClass().getSimpleName().equals("camisa")){
                            matriz[i][6]=lista.get(i).toString();
                        }
                        else{
                            if(lista.get(i).getClass().getSimpleName().equals("sudadera")){
                                matriz[i][6]=lista.get(i).toString();
                            }
                        }
                    }
                }
            }
        }
        jTproductos.setModel(new javax.swing.table.DefaultTableModel(
                matriz,new String[]{"Producto","Codigo","Marca","Talla","Color","Costo","Tipo"}
        ));
    }
    public void mostrarBusqueda(){
        int i;
        String [][] matriz=new String[lista2.tamaño()][7];
        for( i=0;i<lista2.tamaño();i++){
            matriz[i][0]=lista2.get(i).getClass().getSimpleName();
            matriz[i][1]=String.valueOf(lista2.get(i).getCodigo());
            matriz[i][2]=lista2.get(i).getMarca();
            matriz[i][3]=lista2.get(i).getTalla();
            matriz[i][4]=lista2.get(i).getColor();
            matriz[i][5]=String.valueOf(lista2.get(i).getCosto());
            if(lista2.get(i).getClass().getSimpleName().equals("pantalon")){
               matriz[i][6]=lista2.get(i).toString(); 
            }else{
                if(lista2.get(i).getClass().getSimpleName().equals("playera")){
                    matriz[i][6]=lista2.get(i).toString(); 
                }
                else{
                    if(lista2.get(i).getClass().getSimpleName().equals("chamarra")){
                        matriz[i][6]=lista2.get(i).toString(); 
                    }
                    else{
                        if(lista2.get(i).getClass().getSimpleName().equals("camisa")){
                            matriz[i][6]=lista2.get(i).toString(); 
                        }
                        else{
                            if(lista2.get(i).getClass().getSimpleName().equals("sudadera")){
                                matriz[i][6]=lista2.get(i).toString(); 
                            }
                        }
                    }
                }
            }
        }
        jTproductos.setModel(new javax.swing.table.DefaultTableModel(
                matriz,new String[]{"Producto","Codigo","Marca","Talla","Color","Costo","Tipo"}
        ));
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem2 = new javax.swing.JMenuItem();
        jLañadir = new javax.swing.JLabel();
        jLbusqueda = new javax.swing.JLabel();
        jLimagen = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTproductos = new javax.swing.JTable();
        jBactualizar = new javax.swing.JButton();
        jCañadir = new javax.swing.JComboBox<>();
        jCbusqueda = new javax.swing.JComboBox<>();
        jBañadir = new javax.swing.JButton();
        jBbuscar = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMinventario = new javax.swing.JMenuItem();
        jMpedidos = new javax.swing.JMenuItem();

        jMenuItem2.setText("jMenuItem2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Line Clothes");

        jLañadir.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLañadir.setText("Añadir un producto");

        jLbusqueda.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLbusqueda.setText("Busqueda");

        jTproductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTproductos.setGridColor(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(jTproductos);

        jBactualizar.setText("Actualizar");
        jBactualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jBactualizarMouseClicked(evt);
            }
        });

        jCañadir.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona", "Pantalon", "Camisa", "Playera", "Chamarra", "Sudadera" }));

        jCbusqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona", "Codigo", "Marca", "Talla", "Intervalo de precio" }));

        jBañadir.setText("Agregar");
        jBañadir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jBañadirMouseClicked(evt);
            }
        });

        jBbuscar.setText("Buscar");
        jBbuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jBbuscarMouseClicked(evt);
            }
        });

        jMenu1.setText("Menu");

        jMinventario.setText("Inventario total");
        jMinventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMinventarioActionPerformed(evt);
            }
        });
        jMenu1.add(jMinventario);

        jMpedidos.setText("Pedidos de mercancia");
        jMpedidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMpedidosActionPerformed(evt);
            }
        });
        jMenu1.add(jMpedidos);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLimagen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLañadir, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jBañadir)
                                        .addComponent(jCañadir, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 168, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLbusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jCbusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jBbuscar))
                                .addGap(80, 80, 80))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(253, 253, 253)
                        .addComponent(jBactualizar)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLimagen, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLbusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLañadir, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCañadir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCbusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBañadir)
                    .addComponent(jBbuscar))
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBactualizar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jBactualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jBactualizarMouseClicked
        // TODO add your handling code here:
        mostrar();
    }//GEN-LAST:event_jBactualizarMouseClicked

    private void jBañadirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jBañadirMouseClicked
        // TODO add your handling code here:
        int opcion=jCañadir.getSelectedIndex();
        switch(opcion){
            case 0:
                JOptionPane.showMessageDialog(this, "No seleccionaste ninguna opcion\nPorfavor selecciona una prenda para agregar");
            break;
            case 1:
                agregaP a=new agregaP();
                a.setVisible(true);
                lista.agregarProducto(nuevoPantalon=a.regresa());
            break;
            case 2:
                agregaCamisa b=new agregaCamisa();
                b.setVisible(true);
                lista.agregarProducto(nuevaCamisa=b.regresa());
            break;
            case 3:
                agregaPlayera c=new agregaPlayera();
                c.setVisible(true);
                lista.agregarProducto(nuevaPlayera=c.regresa());
            break;
            case 4:
                agregaChamarra d=new agregaChamarra();
                d.setVisible(true);
                lista.agregarProducto(nuevaChamarra=d.regresa());
            break;
            case 5:
                agregaSudadera e=new agregaSudadera();
                e.setVisible(true);
                lista.agregarProducto(nuevaSudadera=e.regresa());
            break;
        }
    }//GEN-LAST:event_jBañadirMouseClicked

    private void jBbuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jBbuscarMouseClicked
        // TODO add your handling code here:
        int opcion=jCbusqueda.getSelectedIndex();
        switch(opcion){
            case 0:
                JOptionPane.showMessageDialog(this, "No seleccionaste ninguna opcion\nPorfavor selecciona un metodo de busqueda");
            break;
            case 1:
                try{
                    numero_busqueda=Integer.parseInt(JOptionPane.showInputDialog(this,"Ingresa el codigo a buscar","Codigo",1));

                    lista2=lista.buscarPorCodigo(numero_busqueda);
                    mostrarBusqueda();
                }
                catch(HeadlessException | NumberFormatException e){
                    System.out.println("No introduciste ningun valor numerico ");
                }
            break;
            case 2:
                busqueda=JOptionPane.showInputDialog(this,"Ingresa la marca","Marca",1);
                lista2=lista.buscarPorMarca(busqueda);
                mostrarBusqueda();
            break;
            case 3:
                busqueda=JOptionPane.showInputDialog(this,"Ingresa la marca","Talla",1);
                lista2=lista.buscarPorTalla(busqueda);
                mostrarBusqueda();
            break;
            case 4:
                try{
                    limiteInf=Integer.parseInt(JOptionPane.showInputDialog(this,"Ingresa el limite inferior","Inferior",1));
                    try{
                        limiteSup=Integer.parseInt(JOptionPane.showInputDialog(this,"Ingresa el limite Superior","Superior",1));
                        lista2=lista.buscarIntervaloCosto(limiteInf,limiteSup);
                        mostrarBusqueda();
                    }
                    catch(HeadlessException | NumberFormatException e){
                    System.out.println("No introduciste ningun valor numerico");
                    } 
                }
                catch(HeadlessException | NumberFormatException e){
                    System.out.println("No introduciste ningun valor numerioc");
                }
            break;
        }
    }//GEN-LAST:event_jBbuscarMouseClicked

    private void jMinventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMinventarioActionPerformed
        // TODO add your handling code here:
        inventarioTotal ventanaTotal = new inventarioTotal();
        ventanaTotal.recibeDatos(lista);
        ventanaTotal.setVisible(true);
    }//GEN-LAST:event_jMinventarioActionPerformed

    private void jMpedidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMpedidosActionPerformed
        // TODO add your handling code here:
        pedidos ventanaPedidos = new pedidos();
        ventanaPedidos.setVisible(true);
    }//GEN-LAST:event_jMpedidosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LineClothes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LineClothes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBactualizar;
    private javax.swing.JButton jBañadir;
    private javax.swing.JButton jBbuscar;
    private javax.swing.JComboBox<String> jCañadir;
    private javax.swing.JComboBox<String> jCbusqueda;
    private javax.swing.JLabel jLañadir;
    private javax.swing.JLabel jLbusqueda;
    private javax.swing.JLabel jLimagen;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMinventario;
    private javax.swing.JMenuItem jMpedidos;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTproductos;
    // End of variables declaration//GEN-END:variables
}
