/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lineclothes;

/**
 *
 * @author Gerry
 */
public class playera extends producto {
    
    private String tipo_cuello;

    public playera(String tipo_cuello, Integer codigo, String marca, String talla, String color, double costo) {
        super(codigo, marca, talla, color, costo);
        this.tipo_cuello = tipo_cuello;
    }

    public playera() {
    }
    

    public String getTipo_cuello() {
        return tipo_cuello;
    }

    public void setTipo_cuello(String tipo_cuello) {
        this.tipo_cuello = tipo_cuello;
    }

    @Override
    public String toString() {
        return tipo_cuello;
    }
    
    
    
}
