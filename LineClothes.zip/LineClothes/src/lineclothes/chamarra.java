/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lineclothes;

/**
 *
 * @author Gerry
 */
public class chamarra extends producto{
    private String temporada;

    public chamarra(String temporada, Integer codigo, String marca, String talla, String color, double costo) {
        super(codigo, marca, talla, color, costo);
        this.temporada = temporada;
    }

    public chamarra() {
    }
    

    public String getTemporada() {
        return temporada;
    }

    public void setTemporada(String temporada) {
        this.temporada = temporada;
    }

    @Override
    public String toString() {
        return temporada;
    }
    
    
}
