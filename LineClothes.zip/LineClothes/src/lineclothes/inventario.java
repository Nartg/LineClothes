/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lineclothes;

import java.util.ArrayList;

/**
 *
 * @author Gerry
 */
public class inventario {
    ArrayList <producto> lista=new ArrayList();

    public inventario() {
    }
    
    public producto get(int indice){
        return lista.get(indice);
    }
    public int tamaño(){
        return lista.size();
    }
    
    public void agregarProducto( producto a ){
        this.lista.add(a);
    }
    
    
    /*
    Para la busqueda por codigo el usuario debera ingresar el codigo a buscar, se iterara sobre el inventario y se
    generara una lista con todos los elementos en el inventario que coincidan con el codigo de buqueda
    */
    
    public inventario buscarPorCodigo(Integer codigo_busqueda){
        inventario lista2=new inventario();
        
        for(producto i: this.lista){
            if(i.getCodigo().equals(codigo_busqueda))
                lista2.agregarProducto(i);
        }

        return lista2;
    }
    
    /*
    Para la busqueda por marca el usuario debera ingresar la marca a buscar, se iterara sobre el inventario y se
    generara una lista con todos los elementos en el inventario que coincidan con el codigo de buqueda
    */
    
    public inventario buscarPorMarca(String marca_busqueda){
        inventario lista2=new inventario();
        
        for(producto i: this.lista){
            if(i.getMarca().equals(marca_busqueda) )
                lista2.agregarProducto(i);
        }
        
        return lista2;
    }
    
    /*
    Para la busqueda por talla el usuario debera ingresar la talla a buscar, se iterara sobre el inventario y se
    generara una lista con todos los elementos en el inventario que coincidan con el codigo de buqueda
    */
    
    public inventario buscarPorTalla(String talla_busqueda){
        inventario lista2=new inventario();
        
        for(producto i: this.lista){
            if(i.getTalla().equals(talla_busqueda) )
                lista2.agregarProducto(i);
        }
        
        return lista2;
    }
    
    /*
    Para la busqueda por rango de costo el usuario debera ingresar un rango de costo( dos datos de tipo double ),
    se iterara sobre el inventario y se
    generara una lista con todos los elementos en el inventario que coincidan con el codigo de buqueda
    */
    
    public inventario buscarIntervaloCosto(double a,double b){
        inventario lista2=new inventario();
        
        for(producto i: this.lista){
            if( i.getCosto()>a && i.getCosto()<b )
                lista2.agregarProducto(i);
        }
        
        return lista2;
    }
    
    
    /*
        La busqueda totales recivira un inventario y regresara un arreglo de tipo integer con los numeros totales:
        [0]: total de pantalones
        [1]: total de Camisas
        [2]: total de playeras
        [3]: total de chamarras
        [4]: Total de sudaderas
    */
    public int[] busquedaTotales(){
        int[] totales=new int[5];
        for(int i=0;i<5;i++){
            totales[i]=0;
        }
        for(producto i:this.lista){
            if(i.getClass().getSimpleName().equals("pantalon"))
                totales[0]++;
            if(i.getClass().getSimpleName().equals("camisa"))
                totales[1]++;
            if(i.getClass().getSimpleName().equals("playera"))
                totales[2]++;
            if(i.getClass().getSimpleName().equals("chamarra"))
                totales[3]++;
            if(i.getClass().getSimpleName().equals("sudadera"))
                totales[4]++;
        }
        return totales;
    }
}